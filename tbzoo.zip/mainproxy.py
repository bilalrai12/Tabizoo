import sys
import threading
import time
import json
from hokireceh_claimer import base
from core.info import get_info
from core.task import process_check_in, process_do_project_task, process_do_normal_task, load_config
from core.mine import process_claim
from core.spin import process_spin
from core.draw import process_draw
from core.upgrade import process_upgrade

sys.dont_write_bytecode = True

config = load_config()

class TabiZoo:
    def __init__(self):
        # Get file directory
        self.proxy_file = base.file_path("proxy.txt")
        self.data_file = base.file_path("data.txt")
        self.config_file = base.file_path("config.json")

        # Initialize line and banner
        self.line = base.create_line(length=50)
        self.banner = base.create_banner(game_name="TabiZoo")

        # Load configurations
        self.auto_check_in = base.get_config(self.config_file, "auto-check-in")
        self.auto_do_task = base.get_config(self.config_file, "auto-do-task")
        self.auto_claim = base.get_config(self.config_file, "auto-claim")
        self.auto_spin = base.get_config(self.config_file, "auto-spin")
        self.auto_draw = base.get_config(self.config_file, "auto-draw")
        self.auto_upgrade = base.get_config(self.config_file, "auto-upgrade")
        self.max_threads = config.get("max-threads", 10)
        self.time_sleep = config.get("time_sleep", 60)

        self.semaphore = threading.Semaphore(self.max_threads)

    def worker(self, account_data, proxy_info):
        """Worker function to process each account."""
        with self.semaphore:
            try:
                formatted_proxies = base.format_proxy(proxy_info=proxy_info)
                actual_ip = base.check_ip(proxy_info=proxy_info)

                # Info
                get_info(data=account_data, proxies=formatted_proxies)

                # Check in
                if self.auto_check_in:
                    base.log(f"{base.green}Starting Check-in...")
                    process_check_in(data=account_data, proxies=formatted_proxies)

                # Do task
                if self.auto_do_task:
                    base.log(f"{base.yellow}Starting Task...")
                    process_do_project_task(data=account_data, proxies=formatted_proxies)
                    process_do_normal_task(data=account_data, proxies=formatted_proxies)

                # Claim
                if self.auto_claim:
                    process_claim(data=account_data, proxies=formatted_proxies)

                # Spin
                if self.auto_spin:
                    process_spin(data=account_data, multiplier=1, proxies=formatted_proxies)
                
                if self.auto_draw:
                    process_draw(data=account_data, proxies=formatted_proxies)

                # Upgrade
                if self.auto_upgrade:
                    base.log(f"{base.yellow}Starting Upgrade...")
                    process_upgrade(data=account_data, proxies=formatted_proxies)

            except Exception as e:
                base.log(f"{base.red}Error in account processing: {base.white}{e}")

    def main(self):
        while True:
            base.clear_terminal()
            print(f"{base.yellow}Tool Shared By B I L A L S T U D I O (https://t.me/Bilalstudio2)")

            with open(self.data_file, "r") as f:
                accounts = f.read().splitlines()
            with open(self.proxy_file, "r") as f:
                proxies = f.read().splitlines()

            num_acc = len(accounts)
            base.log(self.line)
            base.log(f"{base.green}Number of accounts: {base.white}{num_acc}")

            threads = []

            for no, account_data in enumerate(accounts):
                if no < len(proxies):
                    proxy_info = proxies[no]  # Get corresponding proxy
                    thread = threading.Thread(target=self.worker, args=(account_data, proxy_info))
                    threads.append(thread)
                    thread.start()
                else:
                    base.log(f"{base.red} B I L A L S T U D I O || No proxy available for account number {no + 1}")

            # Wait for all threads to complete
            for thread in threads:
                thread.join()

            print()
            wait_time = self.time_sleep * 60
            base.log(f"{base.yellow}Completed all accounts | Wait for {int(wait_time / 60)} minutes!- B I L A L S T U D I O")
            time.sleep(wait_time)

if __name__ == "__main__":
    try:
        tabi = TabiZoo()
        tabi.main()
    except KeyboardInterrupt:
        base.log(f"{base.red}\nProcess interrupted by user. Exiting...")
    except Exception as e:
        base.log(f"{base.red}Error: {base.white}{e}")